import { Component } from '@angular/core';
import { Mydata } from './mydata';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Employee Mgmt System';
  desc ="project is going to be developed by us";
  objMydata:Mydata[];
  constructor()
  {
    this.objMydata=[{
        sno:101,
        name:"sunil kumar",
        address:"vijay nagar",
        phone:987654321
    },{
      sno:102,
      name:"anil kumar",
      address:"anand nagar",
      phone:987654091
  }];
  }
}
