import { Mydata } from './mydata';

describe('Mydata', () => {
  it('should create an instance', () => {
    expect(new Mydata()).toBeTruthy();
  });
});
