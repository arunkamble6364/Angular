export class Mydata {
    sno:number
    name:string
    address:string
    phone:number
}
