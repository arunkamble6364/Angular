import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Student } from '../Student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-form',
  templateUrl: './student-form.component.html',
  styleUrls: ['./student-form.component.css']
})
export class StudentFormComponent implements OnInit {
 
objStud:Student;
  constructor( 
   private route:ActivatedRoute,
   private router:Router,
   private objSS:StudentService) {
    this.objStud= new Student();
   }

  ngOnInit(): void {
  }
  onSubmit()
  {
     this.objSS.saveStudent(this.objStud).subscribe(result=>this.gotoStudentList());  

  }
  gotoStudentList()
  {
    this.router.navigate(['/stlist'])
  }
}
