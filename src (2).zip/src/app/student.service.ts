import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Student } from './Student';
import { Observable } from 'rxjs-compat/Observable';
@Injectable({
  providedIn: 'root'
})
export class StudentService {
 private url:string;
 private status:string;
 constructor(private http:HttpClient) {
   
  this.url="http://localhost:8080/StudentUrl";
  }
 public saveStudent(stObj:Student)
{
  return this.http.post<Student>(this.url,stObj);
  //.subscribe(() => this.status='data saved');
}
public listOfStudent():Observable<Student[]> {
  return this.http.get<Student[]>(this.url);
}
}
