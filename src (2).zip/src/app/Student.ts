export class Student
{
 sid:number
 sname:string
 address:string
 classname:string
}