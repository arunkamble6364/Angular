import { Component, OnInit } from '@angular/core';
import { Student } from '../Student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-studentlist',
  templateUrl: './studentlist.component.html',
  styleUrls: ['./studentlist.component.css']
})
export class StudentlistComponent implements OnInit {
objStudent:Student[];
  
 constructor(private studentService:StudentService) { 
  }

  ngOnInit(): void {
    this.studentService.listOfStudent().subscribe(data =>{
     this.objStudent=data;
    });
  }

}
