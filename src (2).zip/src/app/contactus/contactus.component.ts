import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl, Validators,FormBuilder } from '@angular/forms';
@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent implements OnInit {

  contactusForm:FormGroup;
  constructor(private fb:FormBuilder) {
    this.contactusForm=this.fb.group({
      email:['',[Validators.required,Validators.email]],
      name:['',Validators.required],
      phone:['',Validators.required]
    });

   }

  ngOnInit(): void {
  }
  onSubmit():void{
    
    console.log(this.contactusForm.value);

  }
}
