package StudentRestAPI;

 import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins="http://localhost:4200")// this will enable the request from a parituclar port or ip address
public class StudentRepo {

	@Autowired
	StudentRepository objSR;
	 @PostMapping("/StudentUrl")
	 public String  saveStduent(@RequestBody Student objST)
	 {
		 objSR.save(objST);
		 return "saved!";
	 }
	 @GetMapping("/StudentUrl")
	 public List<Student> getAllStudent()
	 {
		 List<Student> objList= new ArrayList<Student>();
		 objSR.findAll().forEach(objList::add);
		 return objList;
	 }
}
